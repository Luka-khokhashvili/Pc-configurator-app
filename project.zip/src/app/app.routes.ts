import { Routes } from '@angular/router';
import { FinalBuildComponent } from './components/final-build/final-build.component';

export const routes: Routes = [
  { path: 'finalBuild', component: FinalBuildComponent },
  { path: '**', redirectTo: '/', pathMatch: 'full' },
];
