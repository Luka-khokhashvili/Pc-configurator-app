import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-final-build',
  imports: [RouterLink],
  templateUrl: './final-build.component.html',
  styleUrl: './final-build.component.css',
})
export class FinalBuildComponent {}
