export interface CPU {
  partType: string;
  name: string;
  price: number;
  core_count: number;
  core_clock: number;
  boost_clock: number;
  tdp: number;
  graphics: string | null;
  smt: boolean;
}

export interface MOTHERBOARD {
  partType: string;
  name: string;
  price: number;
  socket: string;
  form_factor: string;
  max_memory: number;
  memory_slots: number;
  color: string | null;
}

export interface MEMORY {
  partType: string;
  name: string;
  price: number;
  speed: number[];
  modules: number[];
  price_per_gb: number;
  color: string;
  first_word_latency: number;
  cas_latency: number;
}

export interface VIDEOCARD {
  partType: string;
  name: string;
  price: number;
  chipset: string;
  memory: number;
  core_clock: number;
  boost_clock: number | null;
  color: string;
  length: number;
}

export interface SSD {
  partType: string;
  name: string;
  price: number;
  capacity: number;
  price_per_gb: number;
  type: string;
  cache: number | null;
  form_factor: number;
  interface: number;
}

export interface HDD {
  partType: string;
  name: string;
  price: number | null;
  capacity: number;
  price_per_gb: number | null;
  type: number | null;
  cache: number;
  form_factor: number;
  interface: string;
}

export interface COOLER {
  partType: string;
  name: string;
  price: number;
  rpm: number[] | null;
  noise_level: number[] | null;
  color: string | null;
  size: number | null;
}

export interface CASE {
  partType: string;
  name: string;
  price: string;
  type: string;
  color: string;
  psu: null;
  side_panel: string;
  external_525_bays: number | null;
  internal_35_bays: number | null;
}

export interface ICONS {
  id: string;
  src: string;
}

export type PcPart =
  | CPU
  | MOTHERBOARD
  | MEMORY
  | VIDEOCARD
  | SSD
  | HDD
  | COOLER
  | CASE;
