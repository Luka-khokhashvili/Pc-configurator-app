import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SelectionService {
  finalSelection = signal<any[]>([]);

  getFinalSelection() {
    return this.finalSelection.asReadonly();
  }

  addPart(part: any[]) {
    this.finalSelection.update((parts) => [...parts, part]);
  }

  removePart(partId: number) {
    this.finalSelection.update((parts) =>
      parts.filter((part) => part.name !== partId)
    );
  }

  getTotalPrice(): number {
    return this.finalSelection()
      .map((part) => part.price || 0)
      .reduce((total, price) => total + price, 0);
  }

  clearSelectedList() {
    this.finalSelection.update(() => []);
  }
}
