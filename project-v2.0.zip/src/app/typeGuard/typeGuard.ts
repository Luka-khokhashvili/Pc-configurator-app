import {
  CPU,
  MOTHERBOARD,
  MEMORY,
  VIDEOCARD,
  SSD,
  HDD,
  COOLER,
  CASE,
} from '../interfaces/union-interface';

export function isCPU(part: any): part is CPU {
  return part.partType === 'cpu';
}

export function isMotherboard(part: any): part is MOTHERBOARD {
  return part.partType === 'motherboard';
}

export function isMemory(part: any): part is MEMORY {
  return part.partType === 'memory';
}

export function isVideoCard(part: any): part is VIDEOCARD {
  return part.partType === 'videoCard';
}

export function isSsd(part: any): part is SSD {
  return part.partType === 'ssd';
}

export function isHdd(part: any): part is HDD {
  return part.partType === 'hdd';
}

export function isCooler(part: any): part is COOLER {
  return part.partType === 'cooler';
}

export function isCase(part: any): part is CASE {
  return part.partType === 'cpu';
}
